/*
 * myfuncs.hpp
 *
 *  Created on: Oct 31, 2018
 *      Author: student
 */

#ifndef MYFUNCS_HPP_
#define MYFUNCS_HPP_

#include <string>
#include<climits>
#include<iomanip>
#include<fstream>
#include<cmath>


void Hello(void);

void clearCIN(void);

int userINT(void);

int inputINT(int minimumVal , int maximumVal );

long inputLong(long minVal, long maxVal);

double inputDouble (double minVal, double maxVal);

float inputFloat (float minVal, float maxVal);

int askInt (void);

#endif /* MYFUNCS_HPP_ */
