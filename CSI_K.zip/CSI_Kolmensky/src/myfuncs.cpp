/*
 * myfuncs.cpp
 *
 *  Created on: Oct 31, 2018
 *      Author: student
 */

#include "myfuncs.hpp"
#include <iostream>
using namespace std;

void Hello(void) {
	cout << "Hello there" << endl;
}

void clearCIN(void){
	cin.clear();
	cin.ignore(INT_MAX, '\n');
}

int userINT(void) {
	int counter = 0;
	while (counter >= 50 || counter <= 0) {
		cout << " please enter an number between 0 and 50: ";
		cin >> counter;
		clearCIN();
		if (counter < 0 || counter > 50) {
			cout << "Invalid input, please try again" << endl;
		}	//if
		else {
			break;
		}	//else
	}
	return counter;
}

int inputINT(int minimumVal, int maximumVal) {
	int userInput = 0;

	while (true) {
		cout << " please enter an number between " << minimumVal << " and " << maximumVal << " : ";
		cin >> userInput;
		clearCIN();
		if (userInput > maximumVal || userInput < minimumVal) {
			cout << "Invalid input, please try again" << endl;
		}//if
		else {
			break;
		}//else
	}//while
	return userInput;
}

long inputLong(long minVal, long maxVal){
	long userInput = 0;

	while (true) {
		cout << " please enter an number between " << minVal << " and " << maxVal << " : ";
		cin >> userInput;
		clearCIN();
		if (userInput > maxVal || userInput < minVal) {
			cout << "Invalid input, please try again" << endl;
		}//if
		else {
			break;
		}//else
	}//while
	return userInput;
}

double inputDouble (double minVal, double maxVal){
	int userInput = 0;

	while (true) {
		cout << " please enter an number between " << minVal << " and " << maxVal << " : ";
		cin >> userInput;
		clearCIN();
		if (userInput > maxVal || userInput < minVal) {
			cout << "Invalid input, please try again" << endl;
		}//if
		else {
			break;
		}//else
	}//while
	return userInput;
}

float inputFloat (float minVal, float maxVal){
	int userInput = 0;

	while (true) {
		cout << " please enter an number between " << minVal << " and " << maxVal << " : ";
		cin >> userInput;
		clearCIN();
		if (userInput > maxVal || userInput < minVal) {
			cout << "Invalid input, please try again" << endl;
		}//if
		else {
			break;
		}//else
	}//while
	return userInput;
}

int askInt (void){
	int minimumVal = 0, maximumVal = 50;
	int returnVal = 0;
	int var1;
	var1 = inputINT(minimumVal, maximumVal);
	cout << "input 1: " << var1 << endl;

	int var2;
	var2 = inputINT(minimumVal, maximumVal);
	cout << "input 2:" << var2 << endl;
	returnVal = var1 + var2;

	return returnVal;

	/* return inputINT(minumumVal, MaximumVal) + inputINT(minumumVal, MaximumVal);
	 * return    15 + inputINT(minumumVal, MaximumVal);
	 * return    15 + 50;
	 * return   65;
	 */
}

