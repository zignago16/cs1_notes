//============================================================================
// Name        : CSI_Kolmensky.cpp
// Author      : Andreas Zignago
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>

#include "myfuncs.hpp"
using namespace std;

int main() {
	int minimumVal = 0;
	int maximumVal = 50;
	int userInput;
	Hello();
	cout << "step1" << endl;
	userINT();
	cout << "step 2" << endl;
	userInput = inputINT(minimumVal, maximumVal);
	cout << userInput << endl;
	cout << "step 3" << endl;
	askInt();
	cout << "Program ending" << endl;


	return 0;
}
