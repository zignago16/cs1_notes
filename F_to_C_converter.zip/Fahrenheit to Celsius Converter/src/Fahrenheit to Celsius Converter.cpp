//============================================================================
// Name        : Chapter 2 Project
//Description  : C++ Code displays FTCC temperature converter
// Author      : Zignago, Andreas
// Extra Credit: No
// Date        : 09/20/2018
// OS          : Windows 10 x64 bit
// IDE         : Eclipse
//============================================================================


#include <iostream>
#include <iomanip>

using namespace std;

double TempFahrenheit;
double TempCelsius;
int a;
string b;


int main() {
	Start:
	a = 0;
	TempFahrenheit = 0;
	TempCelsius = 0;

	cout << fixed << setprecision(2) << "Hello I'm FTCC, I can convert your desired temperature from either side and give you the Opposite!" << endl;
	cout << fixed << setprecision(2) << "================================================================================================" << endl;

	cout << "For Fahrenheit to be converted please press & enter 1 \n"<< "If you're looking for Celsius to converted to Fahrenheit please press & enter 2" << endl;
	cout << "or press & enter 0 to exit" << endl;

	cin >> a;

	if ( a == 0 ){
		cout << "Shutting down, thank you for using FTCC! :-)" << endl;
		return 0;
	}

	if (a == 1){
		cout << "You asked for F to C, please enter F: ";
		cin >> TempFahrenheit;

		cout << "You entered: " << TempFahrenheit << " Fahrenheit" << endl;

		TempCelsius = (((TempFahrenheit-32)*5)/9);

		cout << fixed << setprecision(2) <<
					setw(10) << "Celsius" << endl;
					cout << fixed << setprecision(2) <<
								setw(10) << "------------" << endl;
					cout << fixed << setprecision(2) << TempCelsius << endl;


		cout << "This program will now restart to main" << endl;
		cout << "Press any key and enter to continue" << endl;

		cin>>b;
		goto Start;


	}
	else if( a == 2){
		cout << "You asked for C to F, please enter C: ";
		cin >> TempCelsius;

		cout << "You entered: " << TempCelsius << " Celsius" << endl;

		TempFahrenheit = ((TempCelsius*1.8)+32);

		cout << fixed << setprecision(2) <<
					setw(10) << " Fahrenheit" << endl;
					cout << fixed << setprecision(2) <<
								setw(10) << "------------" << endl;
					cout << fixed << setprecision(2) << TempFahrenheit << endl;

		cout << "This program will now restart to main" << endl;
		cout << "Press any key and enter to continue" << endl;

		cin>>b;
		goto Start;

	}else{
		cout << "Invalid Entry! Try again!" << endl;
		goto Start;
	}

	cout << "This program will now end." << endl;

	return 0;
}
