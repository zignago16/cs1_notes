//============================================================================
// Name        : Planetary_Orbital_Velocity_Calculator.cpp
// Author      : Andreas G. Zignago
// Version     :
// Copyright   : Your copyright notice
// Description : Planetary velocity calculator by reading a txt file, Ansi-style
//============================================================================

#include <iostream>
#include"myfuncs.hpp"
using namespace std;

int main() {
	ifstream inputfile;
	string fileName;
	string planetName;
	double planetMass;
	double planetDistance;
	const double Gravity = 6.673e-11;
	const double sunMass = 1.989e30;
	const double sunRadius = 4.32e5;
	const double pi = 3.14159;
	double velocity = 0;
	double period = 0;
	const double orbitalP = 31536000;

	printText("Hello welcome to my planet velocity calculator, please enjoy",1);
	printText("Please enter the location and name of your file: ",1);
	getline(cin,fileName); //user enters file name/location
	inputfile.open(fileName.c_str());
	//or inputfile.open(fileName); both old and new work for eclipse

	cout << setw(25) << " Planet Name " << setw(25) << " Planet Mass(kg) " << setw(25) << " Planet Distance(M) " <<
	setw(25) << "  Avg. Orbital speed(m/s) " << setw(25) << " Orbital Period(y) " << endl;
	cout << setw(25) << " ============= " << setw(25) << " ================ " <<
	setw(25) << " =================== " << setw(25) << " ======================== " << setw(25) << " ================== " << endl;

	if(inputfile.fail()){
		cout << "sorry file read ERROR";
	}//if
	else{
		while( !inputfile.eof()){
				inputfile >> planetName;
				for ( int i=0; i<1; i++){
					//cout << planetName << endl;
					inputfile >>  planetDistance;
					//cout << "Mass amount read:" << planetMass << endl;
					inputfile >> planetMass;
					//cout << "Distance is: " << planetDistance << endl;

					velocity = sqrt((Gravity*sunMass)/(sunRadius+planetDistance));
					period = ((2*(pi*planetDistance))/velocity)/orbitalP;

				}//for

			cout << setw(20) << planetName << setw(22)<< scientific << setprecision(2) <<
				setw(23) << planetMass << setw(23)<< planetDistance <<
				setw(22) << velocity << setw(29) << period << endl;
			}//while
	}//else

	inputfile.close();

	return 0;
}
