/*
 * myfuncs.hpp
 *
 *  Created on: Oct 22, 2018
 *      Author: student
 */
#ifndef MYFUNCS_HPP_
#define MYFUNCS_HPP_
#include <string>
#include<climits>
#include<iomanip>
#include<fstream>
#include<cmath>
using namespace std;

//function prototypes
void clearCIN(void);
void salesReport(void);
void printText (string,int);
//void readNote (void);

#endif /* MYFUNCS_HPP_ */
