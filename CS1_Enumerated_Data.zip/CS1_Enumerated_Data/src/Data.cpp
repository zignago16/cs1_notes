/*
 * Data.cpp
 *
 *  Created on: Dec 3, 2018
 *      Author: student
 */
#include"Data.hpp"

string gstSSSString(SolarSystemType x) {
	if (x == PLANET) {
		return "Planet";
	} else if (x == MOON) {
		return "Moon";
	} //else if
	else {
	} //else
} //end of SSS string

string printInteger(int x){
	return to_string(x);
}

