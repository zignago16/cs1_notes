//============================================================================
// Name        : CS1_Enumerated_Data.cpp
// Author      : Andreas Zignago
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include"Data.hpp"

int main() {
	double x = 2.345e20;
	cout << printInteger(static_cast<int>(x)) << endl;

	SolarSystemType theEarth;
	theEarth = PLANET;
	theEarth = static_cast<SolarSystemType>(01);

	cout << "The Earth is :" << theEarth << endl;
	cout << gstSSSString(theEarth) << endl;

	/*cout << PLANET << endl;
	cout << MOON << endl;
	cout << COMET << endl;
	cout << ASTEROID << endl;
	cout << STAR << endl;
	cout << MINORPLANET << endl;
	cout << COMEROID << endl;*/



	cout << "Program ending" << endl; // prints !!!Hello World!!!
	return 0;
}
