/*
 * Data.hpp
 *
 *  Created on: Dec 3, 2018
 *      Author: student
 */

#ifndef DATA_HPP_
#define DATA_HPP_
#include <iostream>
using namespace std;
enum SolarSystemType {
	DUMMY, //0
	PLANET, //1
	MOON, //2
	COMET, //3
	ASTEROID, //4
	STAR, //5
	MINORPLANET, //6
	COMEROID //7
};
string gstSSSString(SolarSystemType x);
string printInteger(int x);





#endif /* DATA_HPP_ */
