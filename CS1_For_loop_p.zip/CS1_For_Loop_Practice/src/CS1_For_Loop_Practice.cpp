//============================================================================
// Name        : CS1_For_Loop_Practice.cpp
// Author      : Andreas G. Zignago
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

void clearCIN(void) {
	cin.clear();
	cin.ignore(32768, '\n');
} //void


int main() {
//for(int; test; update){
	//statement
	//}//for


	int calories = 0;
	int meal=0;
	//int mealctr = 1;
	double dailcal = 0;
	int mealsaday = 0;
	int ctr2 = 3;

	cout << "please enter how many meals you have had today" << endl;
	cin>> mealsaday;
	clearCIN();

	for(calories = 0, ctr2 = mealsaday; ctr2 > 0; ctr2--){
		cout << " Enter the amount of calories for the day by each meal" << endl;
		cin>> meal;
		clearCIN();
		cout << ctr2 << " meal count" << endl;
		calories = calories + meal;
	}//forlooop

	cout << " total calories for the day "<< endl;
	cout << calories << endl;
	dailcal = calories/mealsaday;
	cout << " average calories per meal: " << dailcal << endl;
	calories = 2000 - calories;
	cout << "Remaing calories: " << calories << endl;
	if ( calories <= 0){
		cout << " STOP EATING SO DAM MUCH YAH PIG" << endl;
	}//if
	else{
		cout << "yah fine be happy :)" << endl;
	}//else


	/*int i = 0;
	int ctr1;
	int runningTotal = 0;
	for (int ctr1 = 0; ctr1 <= 10; ctr1++){
		cout << ctr1 << endl;
		runningTotal += ctr1;

	}
	cout << "runningTotal is :" << runningTotal << endl;
	cout << "i is after the for loop: " << i << endl;

	for ( int i = 0; (i<100 && (i/2)>10); i++) {
		cout << i << endl;
	}*/


	cout << " Program ending have a nice day! :)" << endl; // prints end....



	return 0;
}
