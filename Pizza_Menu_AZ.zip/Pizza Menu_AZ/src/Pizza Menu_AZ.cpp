//============================================================================
// Name        : Pizza.cpp
// Author      : Andreas Zignago
// Version     : 1
// Copyright   : Your copyright notice
// Description : pizza ticket
//============================================================================

#include <iostream>
using namespace std;

/* Pizza name is Cheese
 * The pizza total cost will be Ingredient type=$2 per type
 * The cost to the customer will be "ingredients+delivery=cost"
 * Profit will be 1/4 of cost
 * Delivery cost is 2*Distance
 * size is 10",12",14"
 * Ingredients are pizza dough, Tomato sauce, Chedder&motzerella, Perperrioni, and sausage
 * wheight is 1oz for every ingredient
 * total calories is 100 for every ingredient
 * total protein 2 grams for every ingredient
 * Total Carb 5 grams for every ingredient
 * Gluten Free? yes or n
 * Thin crust? yes or no
 */
double Total;
double cost;
double Delivery;
double Profit;

int Distance;
int Size;
int IngredientTotal;
int Calories;
int Protein;
int Carbs;
int weight;

string Ingredient1;
string Ingredient2;
string Ingredient3;
string Ingredient4;
string Ingredient5;
string CustomerName;
string Intro;

void clearCIN(void){
	//You must do these two lines after a cin into a numaric variable
		//NO WHERE ELSE!!!
		cin.clear();
		cin.ignore(32768,  '\n');
}//clearCIN

int main() {

	Intro= "Hello Welcome to Zignago's Pizzeria!\nPlease Enter your Name";

	cout<<Intro<<endl;
	//cin>>CustomerName; cin dosen't work with string var
	getline(cin, CustomerName);
	cout<<"The Name you chose for your order name is "<<CustomerName;

	cout<<"\n choose your pizza size from 10,12,14 inches";
	cin>> Size;
	clearCIN(); //This will execute the code inside of the clearCIN function defined above main()
	cout<<"The size you chose was "<<Size;

	cout<<"\n Choose your Ingredients you have up to 5."<<endl;
	cout<<"Ingredient 1.";
	getline(cin,Ingredient1);

	cout<<"Ingredient 2.";
	getline(cin,Ingredient2);

	cout<<"Ingredient 3.";
	getline(cin,Ingredient3);

	cout<<"Ingredient 4.";
	getline(cin,Ingredient4);

	cout<<"Ingredient 5.";
	getline(cin,Ingredient5);

	cout<<"you this choose for your pizza "<<Ingredient1<<Ingredient2<<Ingredient3<<Ingredient4<<Ingredient5;
	cout<<" How many Ingredients did you choose?";

	cin>>IngredientTotal;
	clearCIN();
	Calories=IngredientTotal * 200;
	Protein=IngredientTotal * 2;
	Carbs=IngredientTotal * 5;
	cout<<"your Health info is: Calories "<< Calories <<",Protein "<< Protein <<",Carbs "<< Carbs << endl;

	cout<<"service fee is $4. \n"<<" For delivery enter distance from store in miles.";
	cin>>Distance;
	clearCIN();

	cost= Size + IngredientTotal;
	Delivery= Distance * 2;
	Total= (Delivery + 4) + cost;
	cout<<"Your total is:$"<<Total<<endl;

	weight= (IngredientTotal * .5) + (Size*.10);
	cout<<"product weight is:"<<weight<<"lb"<<endl;

	Profit=Total*.25;
	cout<<"out come profit:"<<Profit<<endl;
	return 0;
}
