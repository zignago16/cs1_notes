/*
 * Moon.hpp
 *
 *  Created on: Dec 3, 2018
 *      Author: student
 */

#ifndef MOON_HPP_
#define MOON_HPP_
#include <string>
#include<climits>
#include<iomanip>
#include<fstream>
#include<cmath>
#include<iostream>
#include<cstring>
#include<vector>

using namespace std;

void clearCIN(void);
void salesReport(void);
void printText (string,int);
double CalculateVelocity(double planetDistance);
double CalculatePeriod(double planetDistance, double velocity);
const int SIZE = 40;
int ReadPlanets(double planetMasses[SIZE], double planetDistances[SIZE],
		double planetVelocities[SIZE], float planetPeriods[SIZE],
		string planetNames[SIZE], string fileName);
struct Moon {
	char Name [32];
	double Mass;
	double Distance;
	double Radius;
};
struct Planet{
	char Name[32];
	double Mass;
	double Distance;
	double Radius;
	float Orbital_Velocity;
	float Orbital_Period;
	vector<Moon> Moons;
};

void clearCIN(void);


#endif /* MOON_HPP_ */
