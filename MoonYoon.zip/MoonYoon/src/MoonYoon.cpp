//============================================================================
// Name        : MoonYoon.cpp
// Author      : Andreas Zignago
// Version     : 4
// Copyright   : Your copyright notice
// Description : Planatary information in C++, Ansi-style
//============================================================================

#include "Moon.hpp"


int main() {
	const int SIZE = 40;
	ifstream inputfile;
	string fileName;
	string planetName;
	int counter = 0;
	vector <Planet> planets;
	//Planet planets;

	printText(
			"Hello welcome to my planet velocity calculator Version 4, please enjoy",
			1);
	printText("Please enter the location and name of your file: ", 1);
	getline(cin, fileName); //user enters file name/location
	//inputfile.open(fileName.c_str()); both old
	//or inputfile.open(fileName);  and new work for eclipse
	inputfile.open(fileName.c_str());
	//or inputfile.open(fileName); both old and new work for eclipse
	if (inputfile.fail()) {
		cout << "sorry file read ERROR" << endl;;
	} //if
	else {
		while (!inputfile.eof()) {
			inputfile >> counter;
			if (counter == 01) {
				Planet tempPlanet;
				inputfile >> tempPlanet.Name;
				inputfile >> tempPlanet.Distance;
				inputfile >> tempPlanet.Mass;
				planets.push_back(tempPlanet);
			} else if (counter == 02) {
				Moon tempMoon;
				inputfile >> tempMoon.Name;
				inputfile >> tempMoon.Distance;
				inputfile >> tempMoon.Mass;
				planets[planets.size()-1].Moons.push_back(tempMoon);
				//planets.Moons.push_back(tempMoon);

			} else {
				cout << "Error failed to read file correctly, please check file or seek assistance via technician " << endl;
				return 0;
			}
		}
		inputfile.close();
	}

	cout << "Program ending, Goodbye :)" << endl; // prints !!!Hello World!!!
	return 0;
}
