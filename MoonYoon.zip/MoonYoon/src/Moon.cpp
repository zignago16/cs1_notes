/*
 * Moon.cpp
 *
 *  Created on: Dec 3, 2018
 *      Author: student
 */
#include "Moon.hpp"

void clearCIN(void) {
	cin.clear();
	cin.ignore(INT_MAX, '\n');
}//clearCIN End

/*string gstSSSString(SolarSystemType x) {
	if (x == PLANET) {
		return "Planet";
	} else if (x == MOON) {
		return "Moon";
	} //else if
	else {
	} //else
} //end of SSS string*/

string printInteger(int x){
	return to_string(x);
}
void printText (string aString , int theCount){
	for(int i =0; i<theCount; i++){
		cout<< aString << endl;
	}//for
}
//end function for printText

double CalculateVelocity(double planetDistance) {
	const double Gravity = 6.673e-11;
	const double sunMass = 1.989e30;
	const double sunRadius = 4.32e5;
	double velocity;


	velocity = sqrt((Gravity * sunMass) / (sunRadius + planetDistance));

	return velocity;
}//end of CalculateVelocity

double CalculatePeriod(double planetDistance, double velocity) {
	const double orbitalP = 31536000;
	const double pi = 3.14159;

	double period = ((2*(pi*planetDistance))/velocity)/orbitalP;

	return period;
}//end of CalculatePeriod

int ReadPlanets(double planetMasses[SIZE], double planetDistances[SIZE],
		double planetVelocities[SIZE], float planetPeriods[SIZE],
		string planetNames[SIZE], string fileName) {

	ifstream inputfile;
	int counter = 0;
	//double velocity;
	//double period;

	inputfile.open(fileName.c_str());
	//or inputfile.open(fileName); both old and new work for eclipse
	if (inputfile.fail()) {
		cout << "sorry file read ERROR";
	} //if
	else {
		 cout << setw(25) << " Planet Name " << setw(25) << " Planet Mass(kg) "
		 << setw(25) << " Planet Distance(M) " << setw(25)
		 << "  Avg. Orbital speed(m/s) " << setw(25)
		 << " Orbital Period(y) " << endl;
		 cout << setw(25) << " ============= " << setw(25)
		 << " ================ " << setw(25) << " =================== "
		 << setw(25) << " ======================== " << setw(25)
		 << " ================== " << endl;
		while (!inputfile.eof()) {
			for (int x = 0; x < 8; x++) {
				inputfile >> planetNames[x];
				inputfile >> planetDistances[x];
				inputfile >> planetMasses[x];

				counter++;
				//cout << "counter # " << counter << endl;

				planetVelocities[x] = CalculateVelocity(planetDistances[x]);
				planetPeriods[x] = CalculatePeriod(planetDistances[x],
						planetVelocities[x]);

			} //for
		} //while
	} //else
	inputfile.close();

	return counter++;
}

