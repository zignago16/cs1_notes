 //============================================================================
// Name        : CS1_Arrays.cpp
// Author      : Andreas Zignago
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================


#include "myfuncs.hpp"
using namespace std;

//	void printEmployeeReport(int[], string[], double[]);
//	 const int NUMBEROFEMPLOYEES = 5;
//
// int main() {
//
// 	 const int array1[8] = {10, 20, 30, 40, 50, 60, 70, 80};
//
// 	 for (int i=0; i<8; i++){
// 	 cout << array1[i] << endl;
// 	 }//for
//
// 	 cout << "Program ending please go away " << endl;
//
// 	 int employeeID[NUMBEROFEMPLOYEES] = {10, 20, 30, 40, 50};
// 	 string employeeName[NUMBEROFEMPLOYEES]={"Sam","Sue","Tommy", "cindy", "Todd"};
// 	 double employeeSalery[NUMBEROFEMPLOYEES]={10000, 12000, 8000, 100000, 55000};
//
// 	 printEmployeeReport(employeeID, employeeName, employeeSalery);
//
// return 0;
// }//main1
//
// void printEmployeeReport (int employeeID[], string employeeName[], double employeeSalery[], int arraySize){
//		 cout << "Employee report" << endl;
//		 cout << "================" << endl;
//		 cout << setw(10) << "ID" << setw(30) << "Name" << setw(12) << "Salary" << endl;
//		 cout << setw(10) << "----------" << setw(30) << "---------" << setw(12) << "---------" << endl;
//
//
//			 for (int i=0; i<NUMBEROFEMPLOYEES; i++){
//				 cout << setw(10) << employeeID[i] <<
//					 cout << setw(30) << employeeName[i] <<
//					 cout << setw(12) << employeeSalery[i] << endl;
//			 }//for
//		 }//print employee report



//
//float sumArray (float[], int);
//const int ARRAYCONST = 8;
//
//int main() {
//
//	float arrayFloat[ARRAYCONST] = {15, 27, 34, 42, 53, 69, 78, 81};
//
//	cout <<"Array Total" << sumArray(arrayFloat[], ARRAYCONST) << endl;
//	 cout << "Program ending please go away " << endl;
//return 0;
//}//main1
//
//float sumArray (float arrayFloat[], int ARRAYCONST){
//	float total = 0;
//	 for (int i=0; i<ARRAYCONST; i++){
//	 total += arrayFloat[i];
//	 cout << total << "   added values" << endl;
//	 }//for
//	 return total;
//}//print employee report
