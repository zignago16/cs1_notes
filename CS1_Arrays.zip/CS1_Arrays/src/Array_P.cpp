// Author      : Andreas Zignago
// Version     :
// Copyright   : Your copyright notice
// Description : Array Practice, Ansi-style
//============================================================================


#include "myfuncs.hpp"


double totalVector(vector<double>);

int main() {
//	/*const int NUM_EMPLOYEES = 6;
//	 int hours[NUM_EMPLOYEES];
//	 //get the hours worked by each employee
//	 cout << "Enter the hours worked by " << NUM_EMPLOYEES << " employees" << endl;
//
//	 for (int i=0; i<6; i++){
//	 cout << "Employee #"  << (i+1) << ": ";
//	 hours[i] = inputINT(0,40);
//	 //cin >> hours[i];
//	 }//for1
//
//	 for (int i=0; i<6; i++){
//	 cout << "hours employee #" << (i+1) << " given: " << hours[i] << endl;
//	 }//for2
//
//	 cout << "Range based array loop" << endl;
//	 for(int x:hours){
//	 cout << x << endl;
//	 }//for3
//
//	 cout << "Program ending please go away " << endl;*/
//
//
//
//	double dblArray1[5] = { 1.0, 1.0, 1.0, 1.0, 1.0 };
//
//	cout << "simple array #1" << endl;
//	for (int i = 0; i < 5; i++) {
//		cout << "Array #" << (i + 1) << " Array reads " << setprecision(2)
//				<< fixed << dblArray1[i] << endl;
//	}
//	cout << "array#2" << endl;
//	cout << endl;
//	double dblArray2[10];
//
//	for (int i = 0; i < 10; i++) {
//		dblArray2[i] = 0;
//		cout << "entry #" << (i + 1) << endl;
//	}
//
//	for (int i = 0; i < 10; i++) {
//		cout << "array #" << (i + 1) << "  " << fixed << setprecision(2)
//				<< dblArray2[i] << endl;
//	}
//	cout << "array#3" << endl;
//	string strArray1[6] = { "bubba", "Ella", "Maxx", "wojtek", "winner",
//			"charles" };
//
//	for (int i = 0; i < 6; i++) {
//		cout << "Array #" << (i + 1) << " " << strArray1[i] << endl;
//	}
//
//	cout << "Array#4" << endl;
//	const int ARRAY_SIZE = 10;
//	char charArray1[ARRAY_SIZE] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i',
//			'j' };
//
//	for (int i = 0; i < ARRAY_SIZE; i++) {
//		cout << "Array #" << (i + 1) << " " << charArray1[i] << endl;
//	}
//
//	char lastname[] = "ziggy";
//	cout << lastname << endl;
//
//	for (int i = 0; i < 5; i++) {
//		cout << "Array character " << " " << lastname[i] << endl;
//	}
//
//	cout << " array#5" << endl;
//	for (char val : charArray1) {
//		cout << val << endl;
//	}
//
//	cout << " array#6" << endl;
//	for (char &val : charArray1) {
//		cout << val << endl;
//		val = 'z';
//	}
//
//	int totalItems = 0;
//	double average, sum = 0;
//	double studentGrades[ARRAY_SIZE] = { 0 };
//	int userInput = 0;
//
//	cout << "entering grade cal" << endl << endl;
//
//	while (userInput != 999) {
//		cout << " enter any key to continue other wise enter 999 to leave";
//		userInput = inputINT(0, 999);
//
//		if (userInput != 999) {
//			cout << "please enter in the number of grades to be entered"
//					<< endl;
//			totalItems = inputINT(1, 10);
//
//			cout << "Now please enter in the grade percentages" << endl;
//			for (int i = 0; i < totalItems; i++) {
//				studentGrades[i] = inputINT(0, 100);
//				sum += studentGrades[i];
//			} //for
//			average = sum / totalItems;
//			cout << "average grade: " << average << endl;
//		} //if
//		else {
//		} //else
//
//	} //while
	vector<int> myGrades;
	cout << "the size of my grades vector is:" << myGrades.size() << endl;
	myGrades.push_back(85);
	cout << "the size of my grades vector is:" << myGrades.size() << endl;
	myGrades.push_back(98);
	cout << "the size of my grades vector is:" << myGrades.size() << endl;
	myGrades.push_back(100);
	cout << "the size of my grades vector is:" << myGrades.size() << endl;
	for (int i = 0; i < myGrades.size(); i++) {
		cout << myGrades[i] << endl;
	} //for

	myGrades.clear();
	srand(time(0));
	vector<double>doublevector;

	for(int i= 0; i <20; i++){
		doublevector.push_back(rand()%10);
		}//for

	cout << "total in doublevector: " << totalVector(doublevector) << endl;

	doublevector.clear();

	cout << "program ending please just leave me alone " << endl;
	return 0;
} //main2 */


double totalVector(vector<double>stan){
	double total = 0;
	for(unsigned int i = 0; i < stan.size(); i++){

		total += stan[i];

		}//for
return total;
}//end of total Vector
