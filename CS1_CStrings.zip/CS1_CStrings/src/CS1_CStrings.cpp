//============================================================================
// Name        : CS1_CStrings.cpp
// Author      : Andreas Zignago
// Version     :
// Copyright   : Your copyright notice
// Description : C String work/pracitce, Ansi-style
//============================================================================

#include "honey_pot.hpp"
using namespace std;

int main() {
	string myName = "Samantha";			//string name
	char myName2[32] = "Charles";    //c-string name
	const int CSTRINGSIZE = 7;

	cout << " Showing a regular string" << endl;
	cout << myName << endl;
	for (int i = 0; i < myName.size(); i++) {
		cout << myName[i] << endl;
	}

	cout << "Now for C-strings " << endl;
	cout << myName2 << endl;
	for (int i = 0; i < CSTRINGSIZE; i++) {
		cout << myName2[i] << endl;
	}
	cout << "Clearing our c-string#2 " << endl;

	for (int i = 0; i < CSTRINGSIZE; i++) {
		myName2[i] = '.';
	}
	cout << myName2 << endl;

	char price[20];
	bool decimalEntered = false;

	cout << "Please enter the price for the donut. " << endl;

	//getline(cin,price);
	cin.getline(price, 20);
	cout << " you entered: " << price << endl;

	for (int i = 0; i < 20; i++) {
		if (price[i] == '.' && decimalEntered == false) {
			decimalEntered = true;
			continue;
		} else {
			cout << "to many decimal places!" << endl;
			break;
		}
		if (price[i] == '.') {
			continue;
		} else if (price[i] == '\n' || price[i] == '\0') {
			break;
		} else if (isalpha(price[i])) {
			cout << "Invalid numeric value entered" << endl;
			break;
		} else {
		}    //if/else

	}    //for


	char userData[12];
	int slashEntered;

	cout << " please enter the date for the user. " << endl;
	cin.getline(userData,12);
	cout << "validating the data entered" << endl;


			if(!isdigit(userData[0]) || !isdigit(userData[1]) || !isdigit(userData[3]) || !isdigit(userData[4]) || !isdigit(userData[6]) || !isdigit(userData[7])){
				cout << "Invalid date entered!" << endl;
			}//if
			else if (userData[2] !='/' && userData[5] != '/'){

			}

	cout << userData << endl;











	/*
	 string fileName;
	 ofstream outputfile;
	 cout << " Please enter a file name to open the file. ";
	 getline(cin, fileName);

	 outputfile.open(fileName.c_str());*/// reminder of c-string only processes

	cout << "Program ending please leave :(" << endl; // prints !!!Hello World!!!
	return 0;
}
