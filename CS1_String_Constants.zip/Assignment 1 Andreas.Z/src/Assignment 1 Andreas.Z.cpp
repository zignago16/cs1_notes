//============================================================================
// Name        : CS1_String constants
//Description  : C++ Code displays
// Author      : Zignago, Andreas
// Extra Credit: No
// Date        :
// OS          : Windows 10 x64 bit
// IDE         : Eclipse
//============================================================================

#include <iostream>

using namespace std;

int main() {

	string partnumber;
	const double price_A = 39.99;
	const double price_B = 39.99;

			while (true){
				cout<<"Please enter the part number you would like a price for (end to quit)";
				getline(cin, partnumber);

				if (partnumber == "end") {
				break;
				}//if]
				else if (partnumber == "S-29A"){
					cout << "The price is : $" << price_A << endl;
					break;// end program after price was found
				}//else if

				else if (partnumber == "S-29B"){
					cout << "The price is :$" << price_B << endl;
					break;//end program after price was found
				}//else if

				else{
					cout << "Unknown part number" << endl;
				}//else

			}//while

	return 0;
}
