//============================================================================
// Name        : CS1_Type_Conversions.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <cmath>
using namespace std;

int main() {

		int myInteger = 0;

		myInteger = 22.5 * 3;

		cout<<myInteger<<endl;

		double aDouble = 0.0;

		aDouble = (10 / 3);

		cout << aDouble<<endl;

		int Int1 = 10;
		double Int2 = 3;
		aDouble = (Int1 / Int2);
		cout << aDouble <<endl;

		//static_cast temporarily changes the data type of a variable for a more accurate number
		aDouble = (static_cast<double>(Int1)/(Int2));
		cout<< aDouble << endl;

		cout<< (33 * 33 * 33 * 33) << endl;
		cout<<  static_cast<double>(pow(28,07)) << endl;            //must do an #include <cmath> at the beginning

		int bigInteger = 2147483647;

		cout << "Before add:" << bigInteger<<endl;
		bigInteger++; //bigInteger +=1 or bigInteger = bigInteger +2

		cout<< "After add" << bigInteger<< endl;


		if(bigInteger < 0) {
			cout<< "Error in Calculation"<<endl;
		}//if
		else{
			cout<<"everthing is great"<< endl;
		}







		unsigned int bigUInteger = 4294967295;
		cout << "Before add:(unsigned)" << bigUInteger<<endl;
		bigUInteger++; //bigUInteger +=1 or bigInteger = bigInteger +2

		cout<< "After add:(Unsigned)" << bigUInteger<< endl;


	return 0;
}
