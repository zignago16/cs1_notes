//============================================================================
// Name        : CS1_RanStruct.cpp
// Author      : Andreas Zignago
// Version     : 1
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <fstream>
#include<cstring>
using namespace std;
struct Planet {
	char name[20];
	double radius;
	double distance;
	double mass;
};

int main() {

	Planet mercury, venus, earth, mars, jupiter, saturn, uranus, neptune;
	strcpy(mercury.name, "Mercury");
	//mercury.name = 'Mercury';
	mercury.mass = 100e10;
	mercury.distance = 3.598e7;
	mercury.radius = 1.516e3;
	cout << "Mercury Created" << endl;
	strcpy(venus.name, "Venus");
	venus.mass = 150;
	venus.distance = 200;
	venus.radius = 8;
	cout << "Venus Created" << endl;
	strcpy(earth.name, "Earth, Home");
	earth.mass = 350;
	earth.distance = 300;
	earth.radius = 20;
	cout << "Earth Created" << endl;
	strcpy(mars.name, "Mars");
	mars.mass = 350;
	mars.distance = 400;
	mars.radius = 15;
	cout << "Mars Created" << endl;
	strcpy(jupiter.name, "Jupiter");
	mars.mass = 650;
	mars.distance = 800;
	mars.radius = 25;
	cout << "Jupiter Created" << endl;
	strcpy(saturn.name, "Saturn");
	saturn.mass = 900;
	saturn.distance = 1200;
	saturn.radius = 50;
	cout << "Saturn Created" << endl;
	fstream planetFile;
	planetFile.open("ThePlanets.bin", ios::binary | ios::in | ios::out);
	if (planetFile.fail()) {
		cout << "File ERROR PLEASE SEEK HELP" << endl;
		planetFile.open("ThePlanets.bin", ios::binary | ios::out);
		if (planetFile.fail()) {
			cout << "File ERROR PLEASE SEEK HELP AGAIN" << endl;
			exit(9);
		} else {
		}
	} else {
	}
	cout << "File Opened" << endl;
	planetFile.write(reinterpret_cast<char*>(&mercury), sizeof(mercury));
	planetFile.write(reinterpret_cast<char*>(&venus), sizeof(venus));
	planetFile.write(reinterpret_cast<char*>(&earth), sizeof(earth));
	planetFile.write(reinterpret_cast<char*>(&mars), sizeof(mars));
	planetFile.write(reinterpret_cast<char*>(&jupiter), sizeof(jupiter));
	planetFile.write(reinterpret_cast<char*>(&saturn), sizeof(saturn));
	int planetNumber = 0;
	cout << "Looking for planets" << endl;
	planetFile.seekg(0, ios::end); // Puts seekg at the end of the file
	cout << "Total planets in the file is: " << (planetFile.tellg()/sizeof(Planet)) << endl;
	while (true) {
		cout << "Enter a planet number(1-5), -999 to exit: ";
		cin >> planetNumber;
		if (planetNumber == -999) {
			break;
		} else {
		}
		long positionInFile = sizeof(Planet) * (planetNumber - 1);
		cout << "File Position is: " << positionInFile << endl;
		planetFile.seekg(positionInFile, ios::beg);
		Planet tempPlanet;
		planetFile.read(reinterpret_cast<char*>(&tempPlanet),
				sizeof(tempPlanet));
		cout << "Planet found: " << tempPlanet.name << " , " << tempPlanet.mass
				<<" , " << tempPlanet.distance << " , " << tempPlanet.radius << endl;
		cout << "User please enter in a new mass for the planet: ";

		cin >> tempPlanet.mass;
		//getline(cin, tempPlanet.name);
		planetFile.seekp(positionInFile, ios::beg);
		planetFile.write(reinterpret_cast<char*>(&tempPlanet), sizeof(tempPlanet));
		cout << "Get pointer is at: " << planetFile.tellg() << endl;
		cout << "Put pointer is at: " << planetFile.tellp() << endl;

	}
	planetFile.close();
	cout << "File Closed" << endl;

	cout << "Program Ending, Goodbye :)" << endl;
	return 0;
}
