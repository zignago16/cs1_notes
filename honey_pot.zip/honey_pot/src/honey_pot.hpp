/*
 * honey_pot.hpp
 *
 *  Created on: Nov 7, 2018
 *      Author: student
 */

#ifndef HONEY_POT_HPP_
#define HONEY_POT_HPP_
#include <string>
#include<climits>
#include<iomanip>
#include<fstream>
#include<cmath>
#include<iostream>
using namespace std;


void Hello(void);

void clearCIN(void);

int userINT(void);

int inputINT(int minimumVal , int maximumVal );

long inputLong(long minVal, long maxVal);

double inputDouble (double minVal, double maxVal);

float inputFloat (float minVal, float maxVal);

int askInt (void);





#endif /* HONEY_POT_HPP_ */
