//============================================================================
// Name        : CS1_Validating data
//Description  : C++ Code displays
// Author      : Zignago, Andreas
// Extra Credit: No
// Date        : 9/24/2018
// OS          : Windows 10 x64 bit
// IDE         : Eclipse
//============================================================================

#include <iostream>
using namespace std;

void clearCIN(void){
	cin.clear();
	cin.ignore(32768,'\n');
}


int main() {

	int ageInYears = 0;
	int weightInPounds = 0;
	bool keepGoing = true;

	while(keepGoing){
	 cout << "Please  enter your age in years (0-150, 666 to exit) :";
	 cin >> ageInYears;
	 clearCIN();

	 if (ageInYears == -999) {
		 keepGoing = false;
	 }//if
	 else if (ageInYears > 150 || ageInYears <0) {
		 cout << "Invalid age, should be 0 to 150 only" << endl;
	 }//if
	 else{
		 break;//break out of the while loop if correct
	 }//else
	}//while

	 while(keepGoing){
	 cout << "Please enter your weight in pounds (5-900 pounds)(666 to quit): ";
	 cin >> weightInPounds;
	 clearCIN();
	 if (ageInYears == -999) {
			 keepGoing = false;
		 }//if
	 else if (weightInPounds > 900 || weightInPounds < 5) {
		 cout << "Invalid weight, should be 5 to 900 only" << endl;
	 }//if
	 else{
		 break;//break out of the while loop if correct
	 	 }//else
	 }//while

	cout << "HAVE E NICE DAY" << endl;
	return 0;
}
