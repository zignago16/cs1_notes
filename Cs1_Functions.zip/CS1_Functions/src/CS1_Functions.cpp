//============================================================================
// Name        : CS1_Functions.cpp
// Author      : Andreas Zignago
// Version     :
// Copyright   : Your copyright notice
// Description :
//============================================================================

#include <iostream>
#include "myfuncs.hpp"
using namespace std;

int main() {
	//salesReport();
	printText("Hello",1);
	printText("GoodBye",1);
	doubleNum(5);

	if(keepGoing("would you like to continue")){
		cout << "I'll keep going" << endl;
	}//if
	else{
		cout << "I'll stop" << endl;
	}//else
	cout << "Program ending, have a nice Day!" << endl;



	return 0;
}//main

