//============================================================================
// Name        :
//Description  : C++ Code displays
// Author      : Zignago, Andreas
// Extra Credit: No
// Date        :
// OS          : Windows 10 x64 bit
// IDE         : Eclipse
//============================================================================

#include <iostream>
using namespace std;

int main() {



	return 0;
}
