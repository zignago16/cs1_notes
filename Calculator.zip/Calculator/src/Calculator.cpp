//============================================================================
// Name        :Calculator
//Description  : C++ Code displays
// Author      : Zignago, Andreas
// Extra Credit: No
// Date        : 09/25/2018
// OS          : Windows 10 x64 bit
// IDE         : Eclipse
//============================================================================

#include <iostream>
#include <climits>
using namespace std;

void clearCIN(void){
	cin.clear();
	cin.ignore(32768,'\n');
}//void

int main() {
	double Value1 = 0;
	double Value2 = 0;
	double total = 0;

	char userchoice;

	cout << "Hello! Please enter data for Value#1 and Value#2" << endl;
	cout << "Value#1 :";

	cin >> Value1;
	clearCIN();

	cout << "Value#2 :";
	cin >> Value2;
	clearCIN();

	while(true){
	cout << "Please select from the following options" << endl;
	cout << "A. add the two values" << endl;
	cout << "B. Subtract the two values" << endl;
	cout << "C. Multiply the two values" << endl;
	cout << "D. Divide the two values" << endl;
	cout << "X. Exit Program" << endl;
	cout << "Choice ====>";
	cin >> userchoice;
	clearCIN();

	 switch(toupper(userchoice)){
		 case 'A':{
			 cout << "Adding" << endl;
			 total = Value1 + Value2;
			 cout << "Total: " << total<< endl;
			 break;
		 	 	 }//Case A
		 case 'B':{
			 cout << "Subtractin" << endl;
			 total = Value1 - Value2;
			 cout << "Total: " << total << endl;
			 break;
		 	 	 }//Case B
		 case 'C':{
			 cout << "Multiplying" << endl;
			 total = Value1 * Value2;
			 cout << "Total: " << total << endl;
			break;
		 	 	 }//Case C
		 case 'D':{
			 cout << "Dividing" << endl;
			 total = Value1 / Value2;
			 cout << "Total: " << total << endl;
			 break;
		 	 	 }//Case D
		 case 'X':{
			 cout << "Program closing" << endl;
			 return 0;
		 	 	 }//Case X
		 }//switch
	}//while loop
	return 0;
}

/*Classroom Project
 *
 * 1)Create a new Eclipse program
 * 2)Ask the user to type 2 double values. Value1 and Value2
 * 3)Display a menu with the following options:
 * 	a. Add the two values
 * 	b. subtract the two values
 * 	c. multiply the two values
 * 	d.divide the two values
 * 	x. Exit the program
 * 	4) in a switch statement, implement each of the menu items
 * 		and display the result to the user
 * 	5) Put all of this in a while loop, and leave the loop
 * 	when the user selects option x
 */
