//============================================================================
// Name        : CS_fundWithRand.cpp
// Author      : Andreas G. Zignago
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <ctime>
using namespace std;

int main() {

	srand(time(0));

	cout<<time(0)<<endl;
	cout<<time(0)<<endl;
	cout<<time(0)<<endl;
	cout<<time(0)<<endl;
	cout<<time(0)<<endl;

	cout<<rand()%101<<endl;
	cout<<rand()%101<<endl;
	cout<<rand()%101<<endl;
	cout<<rand()%101<<endl;
	cout<<rand()%101<<endl;
	return 0;
}
