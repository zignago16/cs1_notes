//============================================================================
// Name        : Math.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <cmath>

using namespace std;
// 1) look up pathagorean equation and implement it in C++:
// 2) Einstein's theory of energy:
// 3) Force of gravity:

int main(){

//1)
double c, a, b;
	c= sqrt(  (a*a) + (b*b)  );
	//2)
double m;
const double C=186000;
double E = m * (C*C);

//3)
double Gravity, distance, mass1, mass2;
double Gravity= (mass1 *mass2)/pow(distance, 2);



	return 0;
}
