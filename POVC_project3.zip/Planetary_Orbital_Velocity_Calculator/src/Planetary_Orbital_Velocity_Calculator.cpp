//============================================================================
// Name        : Planetary_Orbital_Velocity_Calculator.cpp
// Author      : Andreas G. Zignago
// Version     : 3.00
// Copyright   : Your copyright notice
// Description : Planetary velocity calculator by reading a txt file into an array function then calling the function into main to be read from memory, Ansi-style.
//============================================================================

#include"myfuncs.hpp"
using namespace std;

int main() {
	const int SIZE = 40;
	ifstream inputfile;
	string fileName;
	string planetName;
	//double planetMass = 0;
	//double planetDistance = 0;
	//double velocity = 0;
	//float period = 0;

	string planetNames[SIZE];
	double planetMasses[SIZE];
	double planetDistances[SIZE];
	double planetVelocities[SIZE];
	float planetPeriods[SIZE];

	int counter;

	printText("Hello welcome to my planet velocity calculator Version 3, please enjoy",
			1);
	printText("Please enter the location and name of your file: ", 1);
	getline(cin, fileName); //user enters file name/location
	//inputfile.open(fileName.c_str()); both old
	//or inputfile.open(fileName);  and new work for eclipse

	counter = ReadPlanets(planetMasses, planetDistances, planetVelocities,
			planetPeriods, planetNames, fileName);

	/*if (inputfile.fail()) {
	 cout << "sorry file read ERROR";
	 } //if
	 else {
	 cout << setw(25) << " Planet Name " << setw(25) << " Planet Mass(kg) "
	 << setw(25) << " Planet Distance(M) " << setw(25)
	 << "  Avg. Orbital speed(m/s) " << setw(25)
	 << " Orbital Period(y) " << endl;
	 cout << setw(25) << " ============= " << setw(25)
	 << " ================ " << setw(25) << " =================== "
	 << setw(25) << " ======================== " << setw(25)
	 << " ================== " << endl;
	 while (!inputfile.eof()) {
	 inputfile >> planetName;
	 for (int i = 0; i < 1; i++) {
	 //cout << planetName << endl;
	 inputfile >> planetDistance;
	 //cout << "Mass amount read:" << planetMass << endl;
	 inputfile >> planetMass;
	 //cout << "Distance is: " << planetDistance << endl;

	 velocity = CalculateVelocity(planetDistance);

	 period = CalculatePeriod(planetDistance, velocity);

	 } //for

	 cout << setw(20) << planetName << setw(22) << scientific
	 << setprecision(2) << setw(23) << planetMass << setw(23)
	 << planetDistance << setw(23) << velocity;
	 cout << fixed << setw(30) << setprecision(2) << period << endl;
	 } //while
	 } //else

	 inputfile.close();*/

	for (int i = 0; i < counter; i++) {
		cout << setw(20) << planetNames[i] << setw(22) << scientific
				<< setprecision(2) << setw(23) << planetMasses[i] << setw(23)
				<< planetDistances[i] << setw(23) << planetVelocities[i];
		cout << fixed << setw(30) << setprecision(2) << planetPeriods[i]
				<< endl;
	}//for

	cout << "Program ending thank you for using POVC.3" << endl;
	return 0;
}
