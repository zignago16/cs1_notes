/*
 * myfuncs.hpp
 *
 *  Created on: Oct 22, 2018
 *      Author: student
 */
#ifndef MYFUNCS_HPP_
#define MYFUNCS_HPP_
#include <string>
#include<climits>
#include<iomanip>
#include<fstream>
#include<cmath>
#include<iostream>
using namespace std;

//function prototypes
void clearCIN(void);
void salesReport(void);
void printText (string,int);
double CalculateVelocity(double planetDistance);
double CalculatePeriod(double planetDistance, double velocity);
const int SIZE = 40;
int ReadPlanets(double planetMasses[SIZE], double planetDistances[SIZE],
		double planetVelocities[SIZE], float planetPeriods[SIZE],
		string planetNames[SIZE], string fileName);
//void readNote (void);

#endif /* MYFUNCS_HPP_ */
