//============================================================================
// Name        : CS1_DO_WHILE_PRACTICE.cpp
// Author      : Andreas G. Zignago
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

void clearCIN(void) {
	cin.clear();
	cin.ignore(32768, '\n');
} //void

int main() {

	int ctr1 = 0;

	while(ctr1 < 20){
		ctr1++;
	cout << "count# :" << ctr1 << endl;
	}// while #1

	ctr1 =0;

	do{
		ctr1++;
	cout << "count# :" << ctr1 << endl;
	}while (ctr1 < 20);// while #2
	int totalLoops = 22;
	while(totalLoops != 0){
		totalLoops--;
		cout << "count# :" << totalLoops << endl;
	}//while#3
	int test = 0;
	double testScore = 0;
	double score = 0;
	cout << "PLease enter in the number of tests in numbers";
	cin>> test;
	clearCIN();
	while(test != 0){
		cout << "please enter test score";
				cin>>score;
				clearCIN();
		testScore = testScore + score;
		test--;
	}//while #4
	cout << " please enter the test # again";
	cin>> test;
	clearCIN();
	testScore = testScore/test;
	cout << " your average score is:" << testScore << endl;
	string x;
	ctr1=0;
	do{
		cout << "please enter in a string of letters or words, to exit please type end or END, or type a to restart" << endl;
		getline(cin,x);
		if(x != "end"&&x!="END"){
			ctr1=ctr1+(x.length());
			continue;
		}//if
		else{}//else

	}while(x!="end" && x!= "END");//while #5
	cout << "total number entered in is: " << ctr1 << endl;
	ctr1=0;
	cout << " Please enter the amount of times you want the loop to loop the loop for loop...";
	cin >> ctr1;
	while(ctr1 !=0){
			ctr1--;
		cout << "count# :" << ctr1 << endl;
		}// while #1

	cout << "loop ended" << endl;
	return 0;
}
