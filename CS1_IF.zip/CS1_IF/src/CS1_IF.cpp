//============================================================================
// Name        : CS1_IF.cpp
// Author      : Andreas Zignago
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

double grade = 45;

int main() {

		if (grade > 90) {
		cout << "you get an A!" << endl;
		cout << "Congrats" << endl;

		}//if
	else {
		if (grade > 80) {
				cout << "you get an B!" << endl;
				cout << "BRAVO" << endl;
			}//if
		else{
			if (grade > 70) {
				cout << "you get an C!" << endl;
				cout << "CHILDISH" << endl;
							}//if
						else{
							if (grade < 60) {
								cout << "you get an D!" << endl;
								cout << "DUMB" << endl;
											}//if
										else{
											if (grade <= 50) {
												cout << "you get an F!" << endl;
												cout << "FOR FAILURE" << endl;
															}//if
					}//else
				}//else
			}//else
		}//else


		if (grade > 90) {
		cout << "you get an A!" << endl;
		cout << "Congrats" << endl;

		}//if
	else if (grade > 80) {
		cout << "you get an B!" << endl;
		cout << "BRAVO" << endl;
			}//if else
	else if (grade > 70) {
		cout << "you get an C!" << endl;
		cout << "CHILDISH" << endl;
							}//if else
	else if (grade < 60) {
		cout << "you get an D!" << endl;
		cout << "DUMB" << endl;
						}//if else
	else if (grade <= 50) {
		cout << "you get an F!" << endl;
		cout << "FOR FAILURE" << endl;
						}//if else






	cout << "program ending have a nice dayyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy" << endl;
	return 0;
}
