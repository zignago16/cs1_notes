//============================================================================
// Name        : CS1_DATAFILES_NumberPractice.cpp
// Author      : Andreas Zignago
// Version     :
// Copyright   : Your copyright notice
// Description : 1. Define a file variable
// 					2. Open the file
// 						3. Process the file
// 							4. Close the file
//============================================================================

#include <iostream>
#include <fstream>
#include <iomanip>
#include <climits>
using namespace std;

void clearCIN (void){
	cin.clear();
	cin.ignore(32768,'\n');
}

void writeNote (void){
//1. Define a file variable
ofstream outputfile;  /// output stream
//const string FILE_NAME = ("SalesFigures.txt");
	string Nameofile;
	cout << "please enter the name of the file you wish to write to:";
	getline(cin,Nameofile);


		outputfile.open(Nameofile);
		string bear;
		bool firstLine = true;

	if(outputfile.fail()){
				cout << "sorry file read ERROR";
		}//if
		else{
			do{
				cout << "Please type a string of text to be entered into a file. OR type end(END) to leave";
				cout << endl;
				getline(cin,bear);
					if(bear != "end" && bear != "END"){
						if(firstLine){
							firstLine = false;
						}//if
					else{
						outputfile << endl;
					}//else
				outputfile << bear;
				}//if
			else{}//else
	}while(bear != "end" && bear != "END");
			}//else
	outputfile.close();
}

int main() {

		ifstream inputfile;
		string fileName;
		string salesName;
		double salesAmount =0;
		double totalSales =0;
		double Annualsales =0;

		cout << "Please enter the location and name of your file: ";
		getline(cin,fileName); //user enters file name/location
		inputfile.open(fileName.c_str());\
		//or inputfile.open(fileName); both old and new work for eclipse

		if(inputfile.fail()){
			cout << "sorry file read ERROR";
		}//if
		else{
			while( !inputfile.eof()){
					inputfile >> salesName;
					for ( int i=0; i<6; i++){
							//cout << "File Reads as: ";
							//cout << endl;
							inputfile >> salesAmount;
							//cout << "Sales amount read:" << salesAmount << endl;
							totalSales += salesAmount;
							//cout << "Total sales are: " << totalSales << endl;
					}//for

					Annualsales += totalSales;
					cout << "Total Sales for " << salesName << " is:$" << setw(5) << fixed << setprecision(2) << totalSales << endl;
					cout << "Average Sales is: $" << fixed << setprecision(2) << totalSales/6 << endl;
					salesAmount = 0;
					totalSales = 0;
					cout << endl;
				}//while
			cout << "Yearly income of maxx and Andreas is:" << Annualsales << endl;
		}//else

		inputfile.close();
	return 0;
}
/*while ( !inputfile.eof()){
	getline(cin,fileName); //Needed to read spaces!!!!
	cout << fileName;
	cout << endl;
}//while*/
