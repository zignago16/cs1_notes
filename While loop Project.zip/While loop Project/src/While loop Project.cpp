//============================================================================
// Name        : While.cpp
// Author      : Andreas Zignago
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

void clearCIN(void) {
	cin.clear();
	cin.ignore(32768, '\n');
} //void

int main() {

	int A = 0;
	double counter1 = 1;
	int B = 0;
	//int counter2 = 0;

	while (A != 10) {
		A += 1;
		counter1 *= 200;
		cout << counter1 << "\n next" << endl;
	}

	A = 0;

	do {
		A += 1;
		counter1 *= 200;
		cout << counter1 << "\n next" << endl;
	} while (A != 10);

	//cout << "please enter an number between 1 and 50000, or enter -999 to exit" << endl;
	//cin >> B;
	//clearCIN();
	/*while (B < 1 || B > 50000) {
	 if (B == -999){
	 break;
	 }//if
	 else if (B < 1 || B > 50000){
	 cout << "error please try again, please enter an number between 1 and 50000" << endl;
	 }//else if
	 else{}//else
	 cout << "please enter an number between 1 and 50000, or enter -999 to exit" << endl;
	 cin >> B;
	 clearCIN();

	 }//while*/
	do {
		cout
				<< "please enter an number between 1 and 50000, or enter -999 to exit"
				<< endl;
		cin >> B;
		clearCIN();

		if (B == -999) {
			break;
		} else if (B < 1 || B > 50000) {
			cout
					<< "error please try again, please enter an number between 1 and 50000"
					<< endl;
		} //else if
		else {
		} //else

	} while (B < 1 || B > 50000); //do while

	//while (counter2  )
	cout << "ending" << endl;
	return 0;
}
