/*
 * myfuncs.cpp
 *
 *  Created on: Oct 22, 2018
 *      Author: student
 */
#include"myfuncs.hpp"
#include<iostream>

void clearCIN (void){
	cin.clear();
	cin.ignore(INT_MAX,'\n');
}
//end function for clearCIN

void salesReport(void){
	//1. Define a output file variable
		ofstream outputfile;  /// output stream
		const string FILE_NAME = ("SalesFigures.txt");
	/*
			outputfile.open(FILE_NAME);
			string bear;
			bool firstLine = true;
			do{
				cout << "Please type a string of text to be entered into a file. OR type end(END) to leave";
				cout << endl;
				getline(cin,bear);
				if(bear != "end" && bear != "END"){
					if(firstLine){
						firstLine = false;
					}//if
					else{
						outputfile << endl;
					}//else
					outputfile << bear;
				}//if
				else{}
			}while(bear != "end" && bear != "END");
			outputfile.close();*/
		//1.define and INputfile
			ifstream inputfile;
			string fileName;
			string salesName;
			double salesAmount =0;
			double totalSales =0;
			double Annualsales =0;
			cout << "Please enter the location and name of your file: ";
			getline(cin,fileName); //user enters file name/location
			inputfile.open(fileName.c_str());\
			//or inputfile.open(fileName); both old and new work for eclipse
			if(inputfile.fail()){
				cout << "sorry file read ERROR";
			}//if
			else{
				while( !inputfile.eof()){
						inputfile >> salesName;
						for ( int i=0; i<6; i++){
								//cout << "File Reads as: ";
								//cout << endl;
								inputfile >> salesAmount;
								//cout << "Sales amount read:" << salesAmount << endl;
								totalSales += salesAmount;
								//cout << "Total sales are: " << totalSales << endl;
						}//for
						Annualsales += totalSales;
						cout << "Total Sales for " << salesName << " is:$" << setw(5) << fixed << setprecision(2) << totalSales << endl;
						cout << "Average Sales is: $" << fixed << setprecision(2) << totalSales/6 << endl;
						salesAmount = 0;
						totalSales = 0;
						cout << endl;
					}//while
				cout << "Yearly income of maxx and Andreas is:" << Annualsales << endl;
			}//else
			inputfile.close();
}
//end fucntion for salesReport

void printText (string aString , int theCount){
	for(int i =0; i<theCount; i++){
		cout<< aString << endl;
	}//for
}
//end function for printText

void writeNote (void){
//1. Define a file variable
ofstream outputfile;  /// output stream
//const string FILE_NAME = ("SalesFigures.txt");
	string Nameofile;
	cout << "please enter the name of the file you wish to write to:";
	getline(cin,Nameofile);


		outputfile.open(Nameofile);
		string bear;
		bool firstLine = true;

	if(outputfile.fail()){
				cout << "sorry file read ERROR";
		}//if
		else{
			do{
				cout << "Please type a string of text to be entered into a file. OR type end(END) to leave";
				cout << endl;
				getline(cin,bear);
					if(bear != "end" && bear != "END"){
						if(firstLine){
							firstLine = false;
						}//if
					else{
						outputfile << endl;
					}//else
				outputfile << bear;
				}//if
			else{}//else
	}while(bear != "end" && bear != "END");
			}//else
	outputfile.close();
}
//end function for writeNote

void readNote (void){

	ifstream inputfile;
	string fileName;
	string planetName;
	double planetMass;
	double planetDistance;


	cout << "Please enter the location and name of your file: ";
	getline(cin,fileName); //user enters file name/location
	inputfile.open(fileName.c_str());\
	//or inputfile.open(fileName); both old and new work for eclipse

	if(inputfile.fail()){
		cout << "sorry file read ERROR";

	}//if
	else{
		while( !inputfile.eof()){
				inputfile >> planetName;
				for ( int i=0; i<2; i++){

						inputfile >>  planetMass;
						cout << "Mass amount read:" << planetMass << endl;
						inputfile >> planetDistance;
						cout << "Distance is: " << planetDistance << endl;
				}//for

			}//while

	}//else

	inputfile.close();
}
//end of function for readNote

double CalculateVelocity(double planetDistance) {
	const double Gravity = 6.673e-11;
	const double sunMass = 1.989e30;
	const double sunRadius = 4.32e5;
	double velocity;


	velocity = sqrt((Gravity * sunMass) / (sunRadius + planetDistance));

	return velocity;
}//end of CalculateVelocity

double CalculatePeriod(double planetDistance, double velocity) {
	const double orbitalP = 31536000;
	const double pi = 3.14159;

	double period = ((2*(pi*planetDistance))/velocity)/orbitalP;

	return period;
}//end of CalculatePeriod
