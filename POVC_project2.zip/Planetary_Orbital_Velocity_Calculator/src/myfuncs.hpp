/*
 * myfuncs.hpp
 *
 *  Created on: Oct 22, 2018
 *      Author: student
 */
#ifndef MYFUNCS_HPP_
#define MYFUNCS_HPP_
#include <string>
#include<climits>
#include<iomanip>
#include<fstream>
#include<cmath>
#include<iostream>
using namespace std;

//function prototypes
void clearCIN(void);
void salesReport(void);
void printText (string,int);
double CalculateVelocity(double planetDistance);
double CalculatePeriod(double planetDistance, double velocity);
//void readNote (void);

#endif /* MYFUNCS_HPP_ */
