//============================================================================
// Name        : CS1_Structs.cpp
// Author      : Andreas Zignago
// Version     : Notes
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================
#include"donuts.hpp"

void clearCIN(void) {
	cin.clear();
	cin.ignore(INT_MAX, '\n');
}

int main() {

	//int stand;
	Donut Donutwheel[80];
	int donutCount = 0;


	//Donut tempDonut = {0, "unknown","unknown",0.0}; This is how you give defult values before C++ V.11
	Donut tempDonut;
	do {
		cout
				<< "Hello and welcome to the Donut structures program, please enter the number of donuts you'd like to enter data for(max 80) or enter -999 to leave the program"
				<< endl;
		cout << "--->";
		cin >> donutCount;
		clearCIN();
	if (donutCount == -999) {
		goto end;
	} else if(donutCount > 80 || donutCount <=  0){
		cout << "Please enter a value between 1 and 80, please" << endl;
	}//else if
} while (donutCount > 80 || donutCount <= 0);
	for (int i = 0; i < donutCount; i++) {
		cout << "Enter -999 to quit the program." << endl;
		cout << "Enter the Calories of your donut:";
		cin >> tempDonut.calories;
		clearCIN();
		if (tempDonut.calories == -999) {
			break;
		} //if
		else {
		}
		cout << "Enter -999 to quit the program." << endl;
		cout << "Enter the cost of your donut:";
		cin >> tempDonut.cost;
		clearCIN();
		if (tempDonut.calories == -999) {
			break;
		} //if
		else {
		}
		cout << "Enter -999 to quit the program." << endl;
		cout << "Enter the filling of your donut:";
		getline(cin, tempDonut.filling);
		if (tempDonut.calories == -999) {
			break;
		} //if
		else {
		}
		cout << "Enter -999 to quit the program." << endl;
		cout << "Enter the Style of your donut:";
		cin.getline(tempDonut.style, 20);
		//strcpy(tempDonut.style, "Chocolate"); Required because style is a c-string
		if (tempDonut.calories == -999) {
			break;
		} //if
		else {
		}
		Donutwheel[i] = tempDonut;

		ingredient tempIng;


		tempIng.ingredient = "Flour";
		tempIng.preparation = "None";
		tempIng.quantity = 32;
		tempIng.source = "Grocery";
		tempIng.temperature = 70;
		tempDonut.ing.push_back(tempIng);

		//tempDonut.ingredientCount++; no longer needed with vectors

		tempIng.ingredient = "Sugar";
		tempIng.preparation = "None";
		tempIng.quantity = 10;
		tempIng.source = "Grocery";
		tempIng.temperature = 70;
		tempDonut.ing.push_back(tempIng);

		tempIng.ingredient = "Butter";
		tempIng.preparation = "Melted";
		tempIng.quantity = 5;
		tempIng.source = "Dairy";
		tempIng.temperature = 90;
		tempDonut.ing.push_back(tempIng);

	Donutwheel[i] = tempDonut;

	}//for

	/*for (int i = 0; i < donutCount; i++) {
		cout << "#" << i + 1 << endl;
		cout << "Donut type: " << Donutwheel[i].style << " , Filling: "
				<< Donutwheel[i].filling << " , Calories: "
				<< Donutwheel[i].calories << " , Cost: " << Donutwheel[i].cost
				<< endl;

	}	//for*/
	cout << endl;

	printAllDounuts(Donutwheel, donutCount);

	//or we can do it manualy
	/*Donut chocolate;
	 cout << "The size of donut stand is: " << sizeof(chocolate) << endl;
	 chocolate.calories = 350;
	 chocolate.cost = 1.29;
	 chocolate.filling = "cake";
	 //chocolate.style = "chocolate"; won't work because a char of 10 doesn't fit a char of 20
	 strcpy(chocolate.style, "chocolate");
	 Donutwheel[donutCount] = chocolate;
	 donutCount++;
	 cout << "Total donuts at Donut wheel is: " << donutCount << endl;
	 Donut Glazed;
	 Glazed.calories = 250;
	 Glazed.cost = .99;
	 Glazed.filling = "plain";
	 strcpy(Glazed.style, "Glazed");
	 Donutwheel[donutCount] = Glazed;
	 donutCount++;
	 cout << "Total donuts at Donut wheel is: " << donutCount << endl;
	 Donut Bearclaw;
	 Bearclaw.calories = 375;
	 Bearclaw.cost = 2.99;
	 Bearclaw.filling = "cinnamon Apple";
	 strcpy(Bearclaw.style, "Bear-Claw");
	 Donutwheel[donutCount] = Bearclaw;
	 donutCount++;
	 cout << "Total donuts at Donut wheel is: " << donutCount << endl;
	 for (int i = 0; i < donutCount; i++) {
	 cout << "#" << i + 1 << endl;
	 cout << "Donut type: " << Donutwheel[i].style << " , Filling: "
	 << Donutwheel[i].filling << " , Calories: "
	 << Donutwheel[i].calories << " , Cost: " << Donutwheel[i].cost
	 << endl;

	 }	//for
	 cout << endl;
	 //cout << "chocolate donut: " << chocolate.style << "," << chocolate.filling
	 //		<< "," << chocolate.calories << "," << chocolate.cost << endl;*/
	end: ;
	cout << "Program ending, good donut" << endl; // prints !!!Hello World!!!
	return 0;
}

void printDonuts(Donut aDonut) {
	cout << "Donut type: " << aDonut.style << " , Filling: " << aDonut.filling
			<< " , Calories: " << aDonut.calories << " , Cost: " << aDonut.cost
			<< endl;
	for (int i = 0; i <aDonut.ing.size(); i++) {
		cout << aDonut.ing[i].ingredient;
		cout << endl;
	} //for
} //Print Donuts

void printAllDounuts(Donut theDonuts[], int numbertoPrint){
	for(int i = 0; i<numbertoPrint; i++){
		printDonuts(theDonuts[i]);
	}//for
}//Print all donuts

