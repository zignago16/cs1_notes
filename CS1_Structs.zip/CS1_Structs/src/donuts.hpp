/*
 * donuts.hpp
 *
 *  Created on: Nov 26, 2018
 *      Author: student
 */

#ifndef DONUTS_HPP_
#define DONUTS_HPP_
#include <string>
#include<climits>
#include<iomanip>
#include<fstream>
#include<cmath>
#include<iostream>
#include<cstring>
#include<vector>
using namespace std;
struct ingredient {
	string ingredient;
	float quantity;
	int temperature;
	string source;
	string preparation;
};

struct Donut {
	int calories = 0; //4 bytes
	string filling = "unknown";	//unknow
	char style[20] = {'.'};	//20 bytes
	float cost = 0;	//4 bytes
	ingredient ings[10];
	vector<ingredient> ing;
	int ingredientCount = 0;
};
void printAllDounuts(Donut theDonuts[], int numbertoPrint);
void printDonuts(Donut adonut);

#endif /* DONUTS_HPP_ */
