//============================================================================
// Name        : CS1_IOMANIP_Intro1.cpp
// Author      : Andreas Zignago
// Version     :
// Copyright   : Your copyright notice
// Description :
//============================================================================

#include <iostream>
#include <iomanip>
using namespace std;

int main() {
	cout << fixed << setprecision(2) <<
			setw(10) << "Quarterly Report" << endl;
	cout << fixed << setprecision(2) <<
			setw(10) << "==================" << endl;




	cout << fixed << setprecision(2) <<
			setw(15) << "Quarter 1" <<
			setw(15) << "Quarter 2" <<
			setw(15) << "Quarter 3" << endl;
	cout << fixed << setprecision(2) <<
			setw(15) << "------------" <<
			setw(15) << "------------" <<
			setw(15) << "------------" << endl;


	double double1 =100.10;
	double double2 = 33;
	double double3 = 92875.22;
	cout << fixed << setprecision(2) <<
			setw(15) << double1 <<
			setw(15) << double2 <<
			setw(15) << double3 << endl;


	double1 = 33;
	double2 = 92875.22;
	double3 = 100.10;
	cout << fixed << setprecision(2) <<
			setw(15) << double1 <<
			setw(15) << double2 <<
			setw(15)<< double3 << endl;

	return 0;
}
