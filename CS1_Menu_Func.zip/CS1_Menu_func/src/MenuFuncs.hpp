/*
 * MenuFuncs.hpp
 *
 *  Created on: Oct 24, 2018
 *      Author: student
 */

#ifndef MENUFUNCS_HPP_
#define MENUFUNCS_HPP_
#include <string>
#include<climits>
#include<iomanip>
#include<fstream>
#include<cmath>
using namespace std;

void displayMenu(char);




#endif /* MENUFUNCS_HPP_ */
