/*
 * MenuFuncs.cpp
 *
 *  Created on: Oct 24, 2018
 *      Author: student
 */
#include"MenuFuncs.hpp"
#include <iostream>

void displayMenu (char){
	cout << "welcome to my program" << endl;
	cout << endl;
	cout << "1) Edit the Planet " << endl;
	cout << "2) Delete the Planet " << endl;
	cout << "3) Print the Report " << endl;
	cout << "x) Exit the program " << endl;
	cout << " Select one please: ";

	//return();
}

