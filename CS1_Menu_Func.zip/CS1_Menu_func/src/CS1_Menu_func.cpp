//============================================================================
// Name        : CS1_Menu_func.cpp
// Author      : Andreas G Zignago
// Version     :
// Copyright   : Your copyright notice
// Description : A menu using functions, Ansi-style
//============================================================================

#include <iostream>
#include "MenuFuncs.hpp"
using namespace std;

int main() {
	char input;
	bool keepgoing = true;

	void displayMenu(char);
	cin>>input;

	while ( input != 'x' && keepgoing !=false){

		switch(toupper (input)){
		case '1': cout << "you entered 1, " << endl;
			keepgoing = false;
			break;
		case '2': cout << "you entered 2, " << endl;
			keepgoing = false;
			break;
		case '3': cout << "you entered 3, " << endl;
			keepgoing = false;
			break;
		case 'X':
		default: cout << "you entered an invailed entry" << endl;
		}//switch

	}//while
return 0;
}//main
