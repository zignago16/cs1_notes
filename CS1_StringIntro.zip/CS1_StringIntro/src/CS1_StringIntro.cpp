//============================================================================
// Name        : CS1_StringIntro.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

int main() {

	string firstName;
	string lastName;
	string fullName;

	cout<<" Enter your First name ";
			getline(cin, firstName);
	cout<<" Enter your Last name ";
			getline(cin, lastName);

			//Example of getting the length of a string
	cout << " Your Name is: " << (firstName.length() +lastName.length()) <<
		" Characters Long "<< endl;

	 //Example of string concatenation (joining) of the strings
	cout << " Thank you " << firstName + " " + lastName << " for participating " << endl;


		fullName = firstName;
		fullName += " ";
		fullName += lastName;

		cout << " Thank you " << fullName << " for participating " << endl;






	return 0;
}
