//============================================================================
// Name        :Satelite Vonversion of velocity
//Description  : C++ Code displays an calculator of converting data to give a velocity of a orbiting satelite
// Author      : Zignago, Andreas
// Extra Credit: No
// Date        :10/1/18
// OS          : Windows 10 x64 bit
// IDE         : Eclipse
//============================================================================

#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

void clearCIN(void) {
	cin.clear();
	cin.ignore(32768, '\n');
} //void

int main() {
	cout << fixed << setw(10) << "Hello, Welcome to PCV calculator, I can calculate an satellite's orbiting velocity of a given planet." << endl;
	cout << fixed << setw(10) << "=====================================================================================================" << endl;
	string PLANET;
	double G = 6.673e-11;
	double M = 0; //planet mass
	double R = 0; // planet radius
	double D = 0; // satellite altitude
	double V = 0; // satellite velocity
	while (true){   //find the length of the string

		do {
			cout << fixed << setw(10)
					<< " Please enter the name of your planet, type (end or END) to exit " << endl;
			cout << fixed << setw(10)
					<< " _________________________________________________________________" << endl;
			cout << " ==> ";
			getline(cin, PLANET);
			if (PLANET == "end" || PLANET == "END") {
				cout << "program shutting down, thank you for using PVCC. :)" << endl;
				return 0;
			} else if (PLANET.length() < 1 || PLANET.length() > 25) {
				cout
						<< " ERROR please enter an name between 1 and 25 characters." << endl;
			} //else-if

		} while (PLANET.length() < 1 || PLANET.length() > 25); //Do-while#1

		do{
		cout <<  fixed << setw(10) << " Please enter the mass of the planet in kilograms(ex 10.2e10) " << endl;
		cout << fixed << setw(10) << " _________________________________________________________________" << endl;
		cout << " ==> ";
		cin>> M;
		clearCIN();
		if (M < 0 || M > 5.98e24){
			cout << "ERROR please make sure your entered value is between 0 and 5.98e24!!" << endl;
		}//if
		else{}//else
		}while(M < 0 || M > 5.98e24);//do-while#2

		do{
			cout << fixed << setw(10) << " Please enter the radius of your planet in meters, (0-6.38e6)" << endl;
			cout << fixed << setw(10) << " _________________________________________________________________" << endl;
			cout << " ==> ";
			cin >> R;
			clearCIN();
			if (R < 0 || R > 6.98e6){
				cout << "ERROR please keep the data entered between 0 and 6380000 meters" << endl;
			}//if
			else{}//else
		}while(R < 0 || R > 6.98e6);//Do-While#3

		do {
			cout <<  fixed << setw(10) << " Please enter the distance your satellite will orbit above the planet in meters. (0-1e6)" << endl;
			cout << fixed << setw(10) << " _________________________________________________________________" << endl;
			cout << " ==> ";
			cin >> D;
			clearCIN();
			if (D < 0 || D > 1e6){
				cout << "ERROR Please keep your numbers between 0-1e6" << endl;
			}//if
			else{}//else
		}while( D < 0 || D > 1e6); //Do-while #4

		V =  sqrt((G*M)/(R+D));//calculation

		cout << fixed << setw(10) << " The velocity of the satellite" << endl;					//main title
		cout << fixed << setw(10) << "================================================" << endl;		//main title lines

		cout << fixed <<
				setw(25) << " Planet " <<
				setw(25) << " Planet Mass " <<
				setw(25) << " Planet Radius" <<			//title
				setw(25) << " Satellite Altitude " <<
				setw(25) << " Satellite Velocity" << endl;
		cout << fixed <<
				setw(25) << "----------------------" <<
				setw(25) << "----------------------" <<
				setw(25) << "----------------------" <<		//title lines
				setw(25) << "----------------------" <<
				setw(25) << "----------------------" << endl;
		cout  << fixed <<
				 setw(25) << PLANET <<
				 scientific<< setw(25) << setprecision(2) << M <<		//data lines
				 scientific<< setw(25) << setprecision(2) << R <<
				 scientific<< setw(25) << setprecision(2) << D <<
				  setw(25) << setprecision(2) << V <<endl;

		//cout << V << "is your velocity of the satellite"<< endl;
		//break;
	}//while loop
	cout << "program shutting down, thank you for using PVCC1. :)" << endl;

	return 0;
}//main
