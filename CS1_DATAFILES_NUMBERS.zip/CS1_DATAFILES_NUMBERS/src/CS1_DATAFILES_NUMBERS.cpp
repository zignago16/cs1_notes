//============================================================================
// Name        : CS1_DATAFILES.cpp
// Author      : Andreas Zignago
// Version     :
// Copyright   : Your copyright notice
// Description : 1. Define a file variable
// 					2. Open the file
// 						3. Process the file
// 							4. Close the file
//								-for numbers :-D
//============================================================================

#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

double salesAmount = 0;
double totalSales = 0;
int numberofSales = 0;

int main() {
	//1. Define a file variable
	ofstream outputfile;  /// output stream
	const string FILE_NAME = ("D:\BearMath.txt");

	//	/*outputfile.open(FILE_NAME);
	//	string bear;
	//	bool firstLine = true;
	//	do{
	//		cout << "Please type a string of text to be entered into a file. OR type end(END) to leave";
	//		cout << endl;
	//		getline(cin,bear);
	//		if(bear != "end" && bear != "END"){
	//			if(firstLine){
	//				firstLine = false;
	//			}//if
	//			else{
	//				outputfile << endl;
		//		}//else
	//			outputfile << bear;
	//		}//if
		//	else{}
	//	}while(bear != "end" && bear != "END");
	//	outputfile.close();*/

		ifstream inputfile;
		string inputString;

		inputfile.open(FILE_NAME);
		if(inputfile.fail()){		//to check for bad files
			cout << "sorry file read ERROR";
		}//if
		else{
			cout << "File Reads as: ";
			cout << endl;
			while ( !inputfile.eof()){
				inputfile >> salesAmount;
				cout << salesAmount;
				cout << endl;
				totalSales += salesAmount;
				numberofSales++;
			}//while
		inputfile.close();
		}//else

		cout << "Total Sales is: " << fixed << setprecision(2) << totalSales << endl;
		cout << "Average Sales is: " << fixed << setprecision(2) << totalSales/numberofSales << endl;
		cout << numberofSales;

	return 0;
}
