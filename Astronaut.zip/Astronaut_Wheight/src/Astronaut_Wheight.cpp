//============================================================================
// Name        : Astronaut_Wheight.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

int wheight1;
int wheight2;
int wheighttotal;

int main() {

	cout <<  " What is your current wheight Number 1!?" << endl;
	cin >> wheight1;

		if ( wheight1 >= 200){

			cout << "YOUR TOO FAT!!! STOP EATING THE DAM TWIXS" << endl;

		}else if (wheight1 <= 50){
			cout << "your TOO SKINNY LAND NOW!! YOU NEED SPAGHETT" << endl;
	}

	cout << " What is your wheight Number 2?!!" << endl;
	cin >> wheight2;

		if ( wheight2 >= 200){

			cout << "YOUR TOO FAT!!! STOP EATING THE DAM KITKATS" << endl;

		}else if (wheight2 <= 50){
			cout << "your TOO SKINNY LAND NOW!! YOU NEED SPAGHETT" << endl;
		}


		wheighttotal = wheight1+wheight2;
		if (wheighttotal <=320){

			cout << "premission to crash, welcome back! :-)" << endl;
		}else{
			cout << "Your too heavy you'll burn up to fast!! ABORTTTTT!!" << endl;
		}





	return 0;
}
