/*
 * CS1_BinaryFiles2.cpp
 *
 *  Created on: Dec 5, 2018
 *      Author: student




#include <iostream>
#include<fstream>
using namespace std;

int main() {
	double mass = 1.23e56;
	double distance = 7.2e44;
	fstream binaryFile;

	binaryFile.open("Planets.bin", ios::out |  ios::binary);

	binaryFile.write(reinterpret_cast<char*>(&mass),sizeof(mass));
	binaryFile.write(reinterpret_cast<char*>(&distance),sizeof(distance));

	binaryFile.close();

	double double1, double2;
	binaryFile.open("Planets.bin", ios::in |  ios::binary);

	binaryFile.read(reinterpret_cast<char*>(&double1),sizeof(double1));
	binaryFile.read(reinterpret_cast<char*>(&double2),sizeof(double2));

	binaryFile.close();

	cout << "The first number read is: " << double1 << endl;
	cout << "The Second number read is: " << double2 << endl;
	cout << "Program ending, good bye" << endl;

}//main*/
