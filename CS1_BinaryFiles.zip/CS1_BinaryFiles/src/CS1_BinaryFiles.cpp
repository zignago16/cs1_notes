//============================================================================
// Name        : CS1_BinaryFiles.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include<fstream>
using namespace std;

void printFile(fstream&x, string y);
void printChar(fstream&x, string y);

int main() {

	fstream theFile;
	string cookieName;
	string fileName;
	cout << "Enter the file you wish to create: ";
	getline(cin,fileName);

	theFile.open(fileName.c_str(),ios::out); //identical to an ofstrean.open(filename)
	if(!theFile.good()){
		cout << "Error writing a cookie!!" << endl;
		exit(99);
	}//if
	else{}
	theFile << "Chocolate chip" << endl;
	theFile << "snickerdoodle" << endl;
	theFile << "TheOpps";
	theFile.close();//close

	printFile(fileName, cookieName);

	theFile.open("Cookies.txt", ios::app);
	theFile <<  endl << "Oatmeal";
	theFile.close();//close


	/*theFile.open("Cookies.txt", ios::in);
	while(!theFile.eof()){
		theFile >> cookieName;
		cout << cookieName << endl;
	}//while
	theFile.close();//close*/

	cout << "!!!Hello World!!!" << endl; // prints !!!Hello World!!!
	return 0;
}//main

void printFile (fstream &x, string y){
	string cookieName;
	int cookieCalories;
	float cookieCost;
	x.open(y.c_str(), ios::in);
	while(!x.eof()){
		getline(x, cookieName, '\t');
		x >> cookieCalories;
		x >> cookieCost;
		cout << cookieName << endl;
	}//while
	x.close();
}//end
void printChar (fstream &x, string y){
	char aCharacter;
	x.open(y.c_str(), ios::in);
	while(!x.eof()){
		x.get(aCharacter);
		cout << aCharacter << endl;
	}//while
	x.close();
}//end
void copyFile(fstream &file1, fstream &file2, string fname1, string fname2){
	char aCharacter;
	file1.open(fname1.c_str(),ios::in);
	file2.open(fname2.c_str(), ios::out);
	while(!file1.eof()){
		file1.get(aCharacter);

	}

}

