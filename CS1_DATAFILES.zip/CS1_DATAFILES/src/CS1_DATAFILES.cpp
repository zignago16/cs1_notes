//============================================================================
// Name        : CS1_DATAFILES.cpp
// Author      : Andreas Zignago
// Version     :
// Copyright   : Your copyright notice
// Description : 1. Define a file variable
// 					2. Open the file
// 						3. Process the file
// 							4. Close the file
//============================================================================

#include <iostream>
#include <fstream>
using namespace std;

int main() {
	//1. Define a file variable
	ofstream outputfile;  /// output stream
	const string FILE_NAME = "D:\BearCave1.txt";

	//2.Open the file
	outputfile.open(FILE_NAME);

	//3. Process the file
	outputfile << "one" << endl;
	outputfile << "two" << endl;
	outputfile << "three" << endl;
	outputfile << "four" << endl;
	outputfile << "five" << endl;
	outputfile << "six" ;
	//last endl will just create an extra space

	//4. Close the file
	outputfile.close();//close file*/


	//1. Define a file variable
		ifstream inputfile;  // input stream
		string inputString;

		//2. Open the file
		inputfile.open(FILE_NAME);

		if (inputfile.fail()){					//file check
			cout << "sorry file error unknown file read";
			cout << endl;
		}//if
		else{

		//3. Process the file
		cout << "file reads as : " << endl;
		/*inputfile >> inputString;

		cout << inputString << endl;
		inputfile >> inputString;
		cout << inputString << endl;
		inputfile >> inputString;
		cout << inputString << endl;
		inputfile >> inputString;
		cout << inputString << endl;
		inputfile >> inputString;
		cout << inputString << endl;
		inputfile >> inputString;
		cout << inputString << endl;
		last endl will just create an extra space*/

		//4. Close the file
		//inputfile.close(); //close file

		while( !inputfile.eof()){
			inputfile >> inputString;
			cout << inputString << endl;
		}//while
		inputfile.close();
		}//else
		outputfile.open("D:\BearC");
		string bear;
		do{
			cout << "Please type a string of text to be entered into a file. OR type end(END) to leave";
			cout << endl;
			getline(cin,bear);
			outputfile << bear;
			outputfile << endl;
		}while(bear != "end" && "END");





	return 0;
}
