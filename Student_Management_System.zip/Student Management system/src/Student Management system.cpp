//============================================================================
// Name        : Student.cpp
// Author      : Andreas G. Zignago
// Version     :
// Copyright   : Your copyright notice
// Description : Student Management System in C++, Ansi-style
//============================================================================

#include <iostream>
#include <iomanip>
using namespace std;

string firstname1;
string lastname1;

double score11;
double score21;
double score31;
double average1;
int wnumber1;

string firstname2;
string lastname2;

double score12;
double score22;
double score32;
double average2;
int wnumber2;

int main() {
	//student 1
	cout << "Welcome to student Managment Program" << endl;

	cout << "Please enter student's first name (1-12 characters in length)" << endl;
	getline (cin , firstname1);

	cout << "Please enter student's last name (1-20 characters in length)" << endl;
	getline (cin , lastname1);

	cout << "Please enter student's W number (1-10 characters in length)" << endl;
	cin >> wnumber1;

	cout << "Enter test score #1" << endl;
	cin >> score11;

	cout << "Enter test score #2" << endl;
	cin >> score21;

	cout << "Enter test score #3" << endl;
	cin >> score31;

	average1 = ((score11 + score21 + score31) / 3); //calculates the scores average

	cout << firstname1 << " " << lastname1 << " " << wnumber1
			<< " Average score is:" << average1 << endl; //display

	//student 2

	cout << "Welcome to student Managment Program" << endl;

	cout << "Please enter student's first name (1-12 characters in length)" << endl;
	cin >> firstname2;

	cout << "Please enter student's last name (1-20 characters in length)" << endl;
	cin >> lastname2;

	cout << "Please enter student's W number (1-10 characters in length)" << endl;
	cin >> wnumber2;

	cout << "Enter test score #1" << endl;
	cin >> score12;

	cout << "Enter test score #2" << endl;
	cin >> score22;

	cout << "Enter test score #3" << endl;
	cin >> score32;

	average2 = ((score12 + score22 + score32) / 3); //calculates the scores average

	cout << firstname2 << " " << lastname2 << " " << wnumber2
			<< " Average score is:" << average2 << endl; //display

	//multiple student display

	cout << fixed << setprecision(2) << setw(10) << "Student Grade Average" << endl;
	cout << fixed << setprecision(2) << setw(10) << "========================"
			<< endl;

	cout << fixed << setprecision(1) << setw(15)
			<< "Student ID" << setw(20)
			<< "Student Test 1" << setw(20)
			<< "Student Test 2" << setw(20)
			<< "Student Test 3" << setw(20)
			<< "Average Grade" << setw(20) << endl;
	cout << fixed << setprecision(1) << setw(15)
			<< "-------------" << setw(20)
			<< "----------------" << setw(20)
			<< "----------------" << setw(20)
			<< "----------------" << setw(20)
			<< "----------------" << setw(20)<< endl;


	cout << fixed << setprecision(1) << setw(15)
			<< wnumber1 << setw(20)
			<< score11 << setw(20)
			<< score21 << setw(20)
			<< score31 << setw(20)
			<< average1 << setw(20) << endl;


	cout << fixed << setprecision(1) << setw(15)
			<< wnumber2 << setw(20)
			<< score12 << setw(20)
			<< score22 << setw(20)
			<< score32 << setw(20)
			<< average2 << setw(20) << endl;

	return 0;
}
