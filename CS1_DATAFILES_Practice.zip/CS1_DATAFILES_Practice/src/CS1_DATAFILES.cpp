//============================================================================
// Name        : CS1_DATAFILES.cpp
// Author      : Andreas Zignago
// Version     :
// Copyright   : Your copyright notice
// Description : 1. Define a file variable
// 					2. Open the file
// 						3. Process the file
// 							4. Close the file
//============================================================================

#include <iostream>
#include <fstream>
using namespace std;

int main() {
	//1. Define a file variable
	ofstream outputfile;  /// output stream
	const string FILE_NAME = ("D:\BearC.txt");

		outputfile.open(FILE_NAME);
		string bear;
		bool firstLine = true;
		do{
			cout << "Please type a string of text to be entered into a file. OR type end(END) to leave";
			cout << endl;
			getline(cin,bear);
			if(bear != "end" && bear != "END"){
				if(firstLine){
					firstLine = false;
				}//if
				else{
					outputfile << endl;
				}//else
				outputfile << bear;
			}//if
			else{}
		}while(bear != "end" && bear != "END");
		outputfile.close();

		ifstream inputfile;
		string inputString;

		inputfile.open(FILE_NAME);
		if(inputfile.fail()){
			cout << "sorry file read ERROR";
		}//if
		else{
			cout << "File Reads as: ";
			cout << endl;
			while ( !inputfile.eof()){
				getline(inputfile,inputString); //Needed to read spaces!!!!
				cout << inputString;
				cout << endl;
			}//while
		inputfile.close();
		}//else

	return 0;
}
