//============================================================================
// Name        :
//Description  : C++ Code displays
// Author      : Zignago, Andreas
// Extra Credit: No
// Date        :
// OS          : Windows 10 x64 bit
// IDE         : Eclipse
//============================================================================

#include <iostream>
using namespace std;

void clearCIN(void) {
	cin.clear();
	cin.ignore(32768, '\n');
} //void

int main() {
	//int ctr = 0;
	double a = 0;
	double total = 0;
	//double obj1 = 0;
	//double dollars = 0;

	/*while (ctr <= 5) {
	 ctr++;
	 cout << " Please enter the dollar amount that you spent on an object"
	 << endl;
	 cin >> obj1;
	 clearCIN();
	 dollars = dollars + obj1;
	 cout << "current amount: " << dollars << endl;

	 if (ctr >= 5) {
	 dollars = dollars / 5;
	 cout << "average amount: " << dollars << endl;
	 break;
	 } //if
	 else {
	 }

	 } //while loop */

	do {
		cout << "Please enter an number between 0 through 100, or -999 to leave"
				<< endl;
		cin >> a;
		clearCIN();
		if (a == -999) {
			//do nothing
		}	//if
		else if (a >= 0 && a <= 100) {
			total = total + a;
			cout << "current value: " << total << endl;
		}	//if
		else {
			cout << "invalid entry try again" << endl;
		}	//else

	} while (a != -999);

	cout << "done" << endl;

	return 0;
}

//ctr = ctr + 1000;
//cout << ctr << endl;
//ctr++;
//cout << ctr-- << endl;
