//============================================================================
// Name        : pizza_structs.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include "ing.hpp"
using namespace std;

void clearCIN(void) {
	cin.clear();
	cin.ignore(INT_MAX, '\n');
}
void printAllPizzas(Pizza thePizzas[], int numbertoPrint);
void printPizzas(Pizza aPizza);

int main() {
	cout << " Hello your about to enter information on pizzas" << endl;
	Pizza AllPizza[80];
	Pizza tempPizza;
	vector<Pizza> Pizzas;
	for(int i = 0; i<2; i++){
		cout << "please enter the Pizza Name: ";
		getline(cin, tempPizza.Name);
		cout << "please enter the cost of your pizza: ";
		cin >> tempPizza.Cost;
		clearCIN();
		cout << " please enter the price of your pizza: ";
		cin >> tempPizza.Price;
		clearCIN();
		cout << "Please enter the number of calories per a slice of your pizza: ";
		cin >> tempPizza.CaloriesPerSlice;
		clearCIN();
		cout << "Now enter the ingredients used on the pizza: ";
		getline(cin, tempPizza.tempIngredients);
		tempPizza.Ingredients.push_back(tempPizza.tempIngredients);
	}

	 printAllPizzas(AllPizza, 2);





	cout << "PRogramendingng" << endl; // prints !!!Hello World!!!
	return 0;
}

void printPizzas(Pizza aPizza) {
	cout << "Pizza name: " << aPizza.Name << " , Price: " << aPizza.Price
			<< " , cost " << aPizza.Cost << " , Calories per a slice: " << aPizza.CaloriesPerSlice
			<< endl;
	for (int i = 0; i <aPizza.Ingredients.size(); i++) {
		cout << aPizza.Ingredients[i];
		cout << endl;
	} //for
} //Print Pizzas

void printAllPizzas(Pizza thePizzas[], int numbertoPrint){
	for(int i = 0; i<numbertoPrint; i++){
		printPizzas(thePizzas[i]);
	}//for
}//prints all pizzas
