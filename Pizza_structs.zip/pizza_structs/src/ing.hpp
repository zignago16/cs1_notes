/*
 * ing.hpp
 *
 *  Created on: Nov 28, 2018
 *      Author: student
 */

#ifndef ING_HPP_
#define ING_HPP_

#include <string>
#include<climits>
#include<iomanip>
#include<fstream>
#include<cmath>
#include<iostream>
#include<cstring>
#include<vector>
using namespace std;

struct Pizza {
	string Name = "Unknown";
	string tempIngredients = "unkown";
	float Cost = 0.00;
	float Price = 0.00;
	int CaloriesPerSlice = 0;
	vector <string>Ingredients;
};




#endif /* ING_HPP_ */
