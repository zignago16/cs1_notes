//============================================================================
// Name        : CS1_My_First_Menu.cpp
// Author      : Andreas Zignao
// Version     :
// Copyright   : Your copyright notice
// Description :
//============================================================================

#include <iostream>
#include <climits>
using namespace std;

int main() {

	char userChoice;

	cout<<"Main Menu"<< endl;
	cout << "========="<<endl;
	cout << "A. Add a new Donut to the menu" << endl ;
	cout << "B. Delete a Donut from the menu" << endl ;
	cout << "C. Order a Donut from the menu" << endl ;
	cout << "D. List all Donuts" << endl ;
	cout << "E. Complain there was a worm in your Donut" << endl ;
	cout << "X. Exit the program" << endl;
	cout << "Choose ====> ";
	cin >> userChoice;
	 //cin.get(userChoice); this doesn't requires a clearing of cin
	 cin.clear();
	 cin.ignore(INT_MAX, '\n');

	 switch(toupper(userChoice)){
	 case 'A':{
		 cout << "You're about to add a new Donut" << endl;
		 break;
	 	 	 }//Case A
	 case 'B':{
		 cout << "You're about to Delete a Donut from the menu" << endl;
		 break;
	 	 	 }//Case B
	 case 'C':{
		 cout << "You're about to order a Donut from the menu" << endl;
		break;
	 	 	 }//Case C
	 case 'D':{
		 cout << "You're about to List all Donuts" << endl;
		 break;
	 	 	 }//Case D
	 case'E':{
		 cout << "eww worm donut" << endl;
		 break;
	 	 	 }//Case E
	 case 'X':{
		 cout << "Program closing" << endl;
		 break;
	 	 	 }//Case X
	 }//while loop

	 cout<< " The User selected " << userChoice << endl;

	 cout << " Program ending, have a nice day" << endl;



	// cout<< "max int size: "<< INT_MAX<< endl;
	 //cout<< "max Short size: "<< Short_MAX << endl;(INPROGRESS)







	return 0;
}
